import { getTeamsByGroup, getMatchTeams } from "./auxiliaryFunctions.js";

/**
 * Calculate the standings of the game for every team in order to qualified them to the next round
 * 
 * @param {Object} matches - Information about all matches
 * @param {Object} groups - Information about each Group
 * @param {Object} teams - Information about each team
 * @param {matchTeams} matchTeams - It relate every match with each participant
 * @returns {Object} All teams wuith their own standindgs
 */
function calculateStandings(matches, groups, teams, matchTeams) {    
  const table = groups.flatMap((group) => {
    const groupTeams = getTeamsByGroup(teams, group.code);

    return groupTeams.map((team) => ({
      id: team.id,
      name: team.name,
      flag: team.flagUrl,
      pj: 0,
      gf: 0,
      gc: 0,
      dg: 0,
      p: 0,
      g: 0,
      e: 0,
      ptos: 0,
    }));
  });

  matches.forEach((match) => {
    const awayScore =match.awayScore !== null ? Number(match.awayScore) : null;
    const homeScore = match.homeScore !== null ? Number(match.homeScore) : null;
    const teamSlots = getMatchTeams(match, matchTeams, teams);

    let tableHome = table.find((team) => team.id === teamSlots.home.team.id);
    let tableAway = table.find((team) => team.id === teamSlots.away.team.id);
    
    //Matches played
    if (homeScore === null && awayScore === null) return;

    tableHome.pj++;
    tableAway.pj++;

    //Goals
    tableHome.gf += homeScore ?? 0;
    tableHome.gc += awayScore ?? 0;
    tableHome.dg = tableHome.gf - tableHome.gc;
    tableAway.gf += awayScore ?? 0;
    tableAway.gc += homeScore ?? 0;
    tableAway.dg = tableAway.gf - tableAway.gc;

    //Matches won, losed or points
    if (homeScore > awayScore) {
      tableHome.g += 1;
      tableHome.ptos += 3;
      tableAway.p += 1;
    } else if (homeScore < awayScore) {
      tableHome.p += 1;
      tableAway.g += 1;
      tableAway.ptos += 3;
    } else {
      tableHome.e += 1;
      tableHome.ptos += 1;
      tableAway.e += 1;
      tableAway.ptos += 1;
    }
  });

  return table;
}

export default calculateStandings;
