 import { getMatchTeams, getTeamById } from "./auxiliaryFunctions.js";

 /**
  * 
  * @param {Matches[]} matches - Every match information
  * @param {MatchTeams[]} matchTeams - Relation in between match and participant teams
  * @param {Teams[]} teams - Every team information
  * @returns {Matches} Information about match and teams in order to get date and flags
  */
 function getBracketData(matches, matchTeams, teams) {
    return matches.map((match) => {
      let teamSlots = getMatchTeams(match, matchTeams, teams);
      
      let homeTeam = getTeamById(teams, teamSlots.home.teamId);
      let awayTeam = getTeamById(teams, teamSlots.away.teamId);
      
      return { match, homeTeam, awayTeam };
    });
  }

  export default getBracketData;